cd node
docker build -t chef:node .
cd ../workstation
docker build -t chef:workstation .
echo "172.25.0.101 node1" >> /etc/hosts
echo "172.25.0.102 node2" >> /etc/hosts
echo "172.25.0.103 node3" >> /etc/hosts
echo "172.25.0.2 workstation" >> /etc/hosts
